---
name: capture
description: 外部からの情報やメモを captures/ フォルダに保存する
trigger: "/capture, メモして, 記録して, 覚えておいて"
references: []
---

# Capture スキル

## 目的

ユーザーが思いついたこと、学んだこと、記録したいことを、
即座に captures/ フォルダにMarkdownファイルとして保存する。

## 手順

1. ユーザーの入力内容を受け取る
2. 以下のフォーマットでファイルを作成:
   - ファイル名: `{YYYY-MM-DD}_{内容を示す英語スラッグ}.md`
   - 例: `2026-04-04_pricing-idea.md`
3. ファイルの中身:
   ```markdown
   ---
   captured: {YYYY-MM-DD HH:MM}
   source: manual
   tags: []
   ---
   
   # {タイトル}
   
   {ユーザーの入力内容}
   ```
4. `captures/` フォルダに保存
5. 保存完了を報告（ファイル名とパスを表示）

## 品質基準

- ユーザーの入力内容を改変しない（そのまま保存）
- ファイル名に日本語を使わない
- 1つのキャプチャにつき1ファイル（複数の話題は分割）

## 出力先

- `captures/` フォルダ
