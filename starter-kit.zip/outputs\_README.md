# outputs/ — 配信最終版（Layer 3）

> **ここにあるものは「そのまま外に出せる」状態です。**

## このフォルダの役割

実際に外部チャネル（ブログ、SNS、メルマガ、note等）に配信する
最終版のコンテンツを保存する場所です。
L1正本（knowledge/）→ L2制作物（teaching/ marketing/）を経て、
チャネルに最適化された状態でここに入ります。

## ここに入れるもの

- ブログ記事の完成版
- SNS投稿（X、Instagram等）の投稿文
- メルマガ・ニュースレターの本文
- note記事の完成版
- YouTube・ポッドキャストの台本
- LP（ランディングページ）の原稿
- キャンペーン素材一式

## フォルダ構成

```
outputs/
├── blog-articles/     ← ブログ記事
├── sns-posts/         ← SNS投稿（X、Instagram等）
├── newsletter/        ← メルマガ・ニュースレター
├── note-articles/     ← note記事
└── （必要に応じて追加）
    ├── youtube-scripts/    ← YouTube台本
    ├── podcast-scripts/    ← ポッドキャスト台本
    └── campaigns/          ← キャンペーン素材
```

必要なサブフォルダだけ使ってください。最初は2〜3個で十分です。

## ファイル名のルール

```
{チャネル}-{連番}_{内容スラッグ}.md
```

**例:**
- `blog-001_why-expertise-matters.md`
- `sns-001_pricing-tips-3points.md`
- `email-001_welcome-sequence.md`
- `note-001_secondbrain-guide.md`

## 配信前チェック（4項目）

outputs/ のファイルを外部に出す前に確認:

- [ ] **正本整合性** — L1正本と矛盾する主張がないか
- [ ] **ブランド一貫性** — トーン、用語、表記が統一されているか
- [ ] **CTA** — 読者に次のアクションを提示しているか
- [ ] **チャネル最適化** — 文字数・フォーマットがチャネルに合っているか

## 重要な原則

outputs/ で問題を見つけたら、**このファイルを直すのではなく、
L1正本（knowledge/）を修正してください**。
源流（L1）を直せば、すべての下流（L2→L3）が改善されます。
