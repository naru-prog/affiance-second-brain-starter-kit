# ============================================
# AIセカンドブレイン — セットアップスクリプト (Windows / PowerShell)
# ============================================
#
# 使い方:
#   1. PowerShell を開く
#   2. cd "$HOME\Documents\my-brain"
#   3. （初回のみ）Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
#   4. .\setup.ps1
#
# 既存ファイルは上書きしません。
# ============================================

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "🧠 AIセカンドブレイン セットアップを開始します..." -ForegroundColor Cyan
Write-Host ""

# --- 0. 前提ツール確認 ---
Write-Host "🔍 前提ツールを確認中..."
$missing = $false
foreach ($cmd in @("git", "code")) {
    if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) {
        Write-Host "  ⚠️  $cmd が見つかりません" -ForegroundColor Yellow
        $missing = $true
    } else {
        Write-Host "  ✅ $cmd"
    }
}

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Host "  ℹ️  gh (GitHub CLI) は未インストール（任意）。winget install GitHub.cli"
}

if ($missing) {
    Write-Host ""
    Write-Host "❌ 必須ツール (git / VS Code) を先にインストールしてください。" -ForegroundColor Red
    Write-Host "   - Git:     winget install Git.Git"
    Write-Host "   - VS Code: winget install Microsoft.VisualStudioCode"
    exit 1
}

# --- 1. フォルダ作成 ---
Write-Host ""
Write-Host "📁 フォルダ構造を作成中..."
$dirs = @(
    "knowledge\business","knowledge\methodology","knowledge\marketing","knowledge\products","knowledge\research",
    "teaching","marketing\blog","marketing\sns","marketing\email",
    "outputs\blog-articles","outputs\sns-posts","outputs\newsletter","outputs\note-articles",
    "captures","_inbox","_archive",
    ".skills\skills\capture",".vscode"
)
foreach ($d in $dirs) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
Write-Host "  ✅ フォルダ構造 完了"

# --- 2. .gitkeep ---
Write-Host "📌 .gitkeep を配置中..."
$keepDirs = @(
    "knowledge\methodology","knowledge\marketing","knowledge\products","knowledge\research",
    "teaching","marketing\blog","marketing\sns","marketing\email",
    "outputs\blog-articles","outputs\sns-posts","outputs\newsletter","outputs\note-articles",
    "captures","_inbox","_archive"
)
foreach ($d in $keepDirs) {
    $f = Join-Path $d ".gitkeep"
    if (-not (Test-Path $f)) { New-Item -ItemType File -Path $f | Out-Null }
}
Write-Host "  ✅ .gitkeep 配置 完了"

# --- 3. Git 初期化 ---
if (-not (Test-Path ".git")) {
    Write-Host "🔧 Git を初期化中..."
    git init -b main | Out-Null
    Write-Host "  ✅ Git 初期化 完了 (branch: main)"
} else {
    Write-Host "ℹ️  Git はすでに初期化済みです"
}

# --- 4. git config ---
Write-Host "👤 Git ユーザー情報を確認中..."
$gitName = (git config --global user.name) 2>$null
$gitEmail = (git config --global user.email) 2>$null

if (-not $gitName) {
    $gitName = Read-Host "  あなたの名前を入力してください (例: Taro Yamada)"
    git config --global user.name "$gitName"
}
Write-Host "  ✅ user.name = $gitName"

if (-not $gitEmail) {
    $gitEmail = Read-Host "  あなたのメールアドレスを入力してください"
    git config --global user.email "$gitEmail"
}
Write-Host "  ✅ user.email = $gitEmail"

# --- 5. .gitignore ---
if (-not (Test-Path ".gitignore")) {
    Write-Host "📝 .gitignore を作成中..."
    @"
# OS
.DS_Store
Thumbs.db

# エディタ一時ファイル
*.swp
*~

# 機密情報
.env
.env.*
secrets/
"@ | Set-Content -Encoding UTF8 .gitignore
    Write-Host "  ✅ .gitignore 作成 完了"
}

# --- 6. GitHub CLI 認証 (任意) ---
if (Get-Command gh -ErrorAction SilentlyContinue) {
    gh auth status 2>$null | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        $yn = Read-Host "🌐 GitHub にログインしますか? [y/N]"
        if ($yn -eq "y" -or $yn -eq "Y") { gh auth login }
    } else {
        Write-Host "✅ GitHub CLI は認証済みです"
    }
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Green
Write-Host "🎉 セットアップ完了！" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Green
Write-Host ""
Write-Host "次のステップ:"
Write-Host "  1. VS Code でこのフォルダを開く:  code ."
Write-Host "  2. CLAUDE.md を開いて、AI相棒の名前とあなたの名前を入れる"
Write-Host "  3. knowledge\business\B-01_business-plan.md をあなた用に書き換える"
Write-Host "  4. 初回コミット:"
Write-Host "       git add ."
Write-Host "       git commit -m 'initial setup'"
Write-Host ""
Write-Host "  （任意）GitHub にリポジトリを作る:"
Write-Host "       gh repo create my-brain --private --source=. --push"
Write-Host ""
