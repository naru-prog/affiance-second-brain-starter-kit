# セットアップ完全ガイド — 初心者向け

> ターミナル/PowerShell を初めて触る人でも詰まらないように、画面操作のレベルから順に書いています。所要時間: 約30分。

---

## 0. このスターターキットでできること

実行すると、以下が一気に整います。

- AIセカンドブレインのフォルダ構造（L1正本 / L2制作物 / L3配信版 / 補助）
- Git によるバージョン管理（変更履歴の自動記録）
- VS Code 推奨拡張機能の登録
- AI相棒の取扱説明書（CLAUDE.md）雛形
- 最初の正本テンプレート（B-01 事業計画）

---

## 1. 必須ツールを先にインストール

### Mac の場合

| ツール | インストール方法 |
|---|---|
| **Git** | ターミナルで `git --version` → 出なければ案内に従う、または `brew install git` |
| **VS Code** | https://code.visualstudio.com/ からダウンロード → 起動後 `Cmd+Shift+P` → `Shell Command: Install 'code' command in PATH` を実行 |
| **GitHub CLI** (任意) | `brew install gh` |

### Windows の場合

| ツール | インストール方法 |
|---|---|
| **Git** | PowerShell で `winget install Git.Git` |
| **VS Code** | `winget install Microsoft.VisualStudioCode` |
| **GitHub CLI** (任意) | `winget install GitHub.cli` |

---

## 2. スターターキットを配置する

1. このフォルダ (`starter-kit/`) を、好きな場所にコピー
   - Mac 推奨: `~/Documents/my-brain`
   - Windows 推奨: `%USERPROFILE%\Documents\my-brain`
2. フォルダ名を `my-brain`（または好きな名前）にリネーム

---

## 3. セットアップスクリプトを実行

### Mac

```bash
cd ~/Documents/my-brain
chmod +x setup.sh
./setup.sh
```

### Windows (PowerShell)

```powershell
cd "$HOME\Documents\my-brain"
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\setup.ps1
```

途中で「あなたの名前」「メールアドレス」を聞かれたら入力してください（Git のコミット記録に使われます）。

---

## 4. VS Code で開く

```
code .
```

初回は推奨拡張機能のインストール提案が出ます → **「Install All」をクリック**。

入る拡張:
- Claude Code（AI相棒の本体）
- Draw.io Integration（ダイアグラム作成）
- Markdown All in One
- YAML

---

## 5. CLAUDE.md をあなた用にカスタマイズ

`CLAUDE.md` を開いて、以下の3箇所を埋めるだけでスタートできます。

```
あなたは「（ここにAI相棒の名前）」です。     ← 例: Serena
（あなたの名前）の相棒として機能します。     ← 例: 山田太郎
```

> 💡 名前が決まらなければ、Claude Code に「私のAI相棒の名前を3つ提案して」と頼んでもOK。

---

## 6. 最初のコミット

```
git add .
git commit -m "initial setup"
```

これで「セーブポイント」が作成されました。今後、いつでもこの状態に戻せます。

---

## 7. (任意) GitHub にバックアップ

```
gh repo create my-brain --private --source=. --push
```

**必ず `--private` を付けてください。** 公開リポジトリにすると正本が全世界に見えます。

---

## 困ったとき

- **`code` コマンドが動かない (Mac)** → VS Code を起動 → `Cmd+Shift+P` → `Shell Command: Install 'code' command in PATH`
- **`./setup.sh: Permission denied`** → `chmod +x setup.sh` を先に実行
- **PowerShell でスクリプトが実行できない** → `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` を先に実行
- **何か壊した気がする** → `git status` → `git restore .` で直前のコミット状態に戻る

---

## 次にやること

1. `knowledge/business/B-01_business-plan.md` をあなたの事業内容に書き換える
2. Claude Code を起動して「私のセカンドブレインの構造を確認して」と話しかける
3. 思いついたメモは何でも `captures/` に放り込む（AI が後で正本化してくれます）
