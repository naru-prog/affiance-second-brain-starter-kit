#!/bin/bash
# ============================================
# AIセカンドブレイン — セットアップスクリプト（Mac / Linux 用）
# ============================================
#
# 使い方:
#   1. ターミナルを開く
#   2. cd ~/Documents/my-brain   （配置したい場所へ）
#   3. chmod +x setup.sh
#   4. ./setup.sh
#
# 既存ファイルは上書きしません。不足分のみ作成します。
# ============================================

set -e

echo ""
echo "🧠 AIセカンドブレイン セットアップを開始します..."
echo ""

# --- 0. 前提ツール確認 ---
echo "🔍 前提ツールを確認中..."

missing=0
for cmd in git code; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "  ⚠️  $cmd が見つかりません"
    missing=1
  else
    echo "  ✅ $cmd"
  fi
done

if ! command -v gh >/dev/null 2>&1; then
  echo "  ℹ️  gh (GitHub CLI) は未インストール（任意）。Homebrewで: brew install gh"
fi

if [ "$missing" -eq 1 ]; then
  echo ""
  echo "❌ 必須ツール (git / VS Code の 'code' コマンド) を先にインストールしてください。"
  echo "   - Git:     https://git-scm.com/  または  brew install git"
  echo "   - VS Code: https://code.visualstudio.com/  → Command Palette で 'Shell Command: Install code command' 実行"
  exit 1
fi

# --- 1. フォルダ作成 ---
echo ""
echo "📁 フォルダ構造を作成中..."

mkdir -p knowledge/business knowledge/methodology knowledge/marketing knowledge/products knowledge/research
mkdir -p teaching marketing/blog marketing/sns marketing/email
mkdir -p outputs/blog-articles outputs/sns-posts outputs/newsletter outputs/note-articles
mkdir -p captures _inbox _archive
mkdir -p .skills/skills/capture
mkdir -p .vscode

echo "  ✅ フォルダ構造 完了"

# --- 2. .gitkeep を配置 ---
echo "📌 .gitkeep を配置中..."
for dir in \
  knowledge/methodology knowledge/marketing knowledge/products knowledge/research \
  teaching marketing/blog marketing/sns marketing/email \
  outputs/blog-articles outputs/sns-posts outputs/newsletter outputs/note-articles \
  captures _inbox _archive
do
  [ -f "$dir/.gitkeep" ] || touch "$dir/.gitkeep"
done
echo "  ✅ .gitkeep 配置 完了"

# --- 3. Git 初期化 ---
if [ ! -d ".git" ]; then
  echo "🔧 Git を初期化中..."
  git init -b main >/dev/null
  echo "  ✅ Git 初期化 完了 (branch: main)"
else
  echo "ℹ️  Git はすでに初期化済みです"
fi

# --- 4. git config (user.name / user.email) 確認 ---
echo "👤 Git ユーザー情報を確認中..."
git_name=$(git config --global user.name || true)
git_email=$(git config --global user.email || true)

if [ -z "$git_name" ]; then
  read -r -p "  あなたの名前を入力してください (例: Taro Yamada): " input_name
  git config --global user.name "$input_name"
  echo "  ✅ user.name = $input_name"
else
  echo "  ✅ user.name = $git_name"
fi

if [ -z "$git_email" ]; then
  read -r -p "  あなたのメールアドレスを入力してください: " input_email
  git config --global user.email "$input_email"
  echo "  ✅ user.email = $input_email"
else
  echo "  ✅ user.email = $git_email"
fi

# --- 5. .gitignore 作成 ---
if [ ! -f ".gitignore" ]; then
  echo "📝 .gitignore を作成中..."
  cat > .gitignore << 'EOF'
# OS
.DS_Store
Thumbs.db

# エディタ一時ファイル
*.swp
*~

# 機密情報
.env
.env.*
secrets/
EOF
  echo "  ✅ .gitignore 作成 完了"
fi

# --- 6. GitHub CLI 認証 (任意) ---
if command -v gh >/dev/null 2>&1; then
  if ! gh auth status >/dev/null 2>&1; then
    echo ""
    echo "🌐 GitHub にログインしますか？ (リポジトリをクラウドにバックアップする場合)"
    read -r -p "   今すぐログインする? [y/N]: " yn
    if [ "$yn" = "y" ] || [ "$yn" = "Y" ]; then
      gh auth login
    else
      echo "   ⏭  スキップ。あとで 'gh auth login' を実行できます。"
    fi
  else
    echo "✅ GitHub CLI は認証済みです"
  fi
fi

# --- 完了 ---
echo ""
echo "============================================"
echo "🎉 セットアップ完了！"
echo "============================================"
echo ""
echo "次のステップ:"
echo "  1. VS Code でこのフォルダを開く:  code ."
echo "  2. CLAUDE.md を開いて、AI相棒の名前とあなたの名前を入れる"
echo "  3. knowledge/business/B-01_business-plan.md をあなた用に書き換える"
echo "  4. 初回コミット:"
echo "       git add ."
echo "       git commit -m 'initial setup'"
echo ""
echo "  （任意）GitHub にリポジトリを作る:"
echo "       gh repo create my-brain --private --source=. --push"
echo ""
